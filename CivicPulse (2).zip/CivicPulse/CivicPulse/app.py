import os, re, secrets
from pathlib import Path
from datetime import datetime, timezone
from functools import wraps

import certifi
from bson import ObjectId
from bson.errors import InvalidId
from dotenv import load_dotenv
from flask import Flask, abort, flash, redirect, render_template_string, request, session, url_for
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
from markupsafe import escape

load_dotenv()
BASE = Path(__file__).resolve().parent
UPLOAD_FOLDER = BASE / 'static' / 'uploads'
UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
ALLOWED = {'png', 'jpg', 'jpeg', 'webp'}
app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY') or secrets.token_hex(32)
app.config.update(MAX_CONTENT_LENGTH=5 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')
uri = os.getenv('MONGO_URI')
if not uri:
    raise RuntimeError('MONGO_URI is missing. Check your .env file; do not share its contents.')
client = MongoClient(uri, tlsCAFile=certifi.where(), serverSelectionTimeoutMS=10000)
db = client['CivicPulse']
complaints, users = db['complaints'], db['users']
try: users.create_index('email', unique=True)
except Exception: pass
STATUSES = ['Pending', 'In Progress', 'Resolved']
PRIORITIES = ['High', 'Medium', 'Low']
CATEGORIES = ['Garbage and Waste', 'Water Leakage', 'Road Damage', 'Streetlight', 'Drainage', 'Electricity', 'Public Safety', 'Other']

CSS = r'''
:root{color-scheme:dark;--bg:#07111f;--panel:#101e31;--panel2:#14263d;--line:#263b55;--text:#edf4ff;--muted:#9db0c8;--blue:#4e8cff;--cyan:#37d6d0;--green:#42d6a0;--amber:#ffd06b;--red:#ff8297}*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 10% 0%,#142b49 0,transparent 42%),var(--bg);color:var(--text);font:15px/1.55 Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}a{color:inherit;text-decoration:none}button,.btn,input,select,textarea{font:inherit}button,.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:11px;padding:11px 16px;background:linear-gradient(135deg,var(--blue),#7468ff);color:white;font-weight:750;cursor:pointer}button:hover,.btn:hover{filter:brightness(1.12)}.btn.secondary{background:#203650;border:1px solid #38516e}.btn.teal{background:linear-gradient(135deg,#10bdb1,#168bd3)}.btn.small{padding:7px 10px;font-size:12px}.top{position:sticky;top:0;z-index:5;display:flex;align-items:center;justify-content:space-between;gap:16px;padding:13px max(20px,calc((100vw - 1380px)/2));background:#091626ed;border-bottom:1px solid var(--line);backdrop-filter:blur(14px)}.brand{display:flex;align-items:center;gap:10px;font-size:20px;font-weight:900;letter-spacing:-.5px;white-space:nowrap}.logo{width:39px;height:39px;display:grid;place-items:center;border-radius:12px;background:linear-gradient(135deg,var(--cyan),var(--blue));color:#07111f;font-weight:950}.nav{display:flex;gap:5px;align-items:center;flex-wrap:wrap}.nav a{padding:9px 11px;border-radius:9px;color:var(--muted);font-size:13px}.nav a:hover,.nav a.active{background:#1a2d45;color:white}.who{font-size:12px;color:var(--muted);border:1px solid var(--line);padding:7px 10px;border-radius:99px}.wrap{max-width:1380px;padding:27px;margin:auto}.hero{display:flex;align-items:flex-end;justify-content:space-between;gap:18px;margin:8px 0 25px}.eyebrow{color:var(--cyan);font-size:11px;font-weight:850;letter-spacing:2px;text-transform:uppercase}h1{font-size:clamp(29px,3vw,41px);line-height:1.12;letter-spacing:-1.3px;margin:8px 0 10px}h2{font-size:19px;letter-spacing:-.3px;margin:0 0 15px}h3{font-size:16px;margin:0 0 8px}.muted,.hint{color:var(--muted)}.grid{display:grid;gap:16px}.stats{grid-template-columns:repeat(4,minmax(0,1fr));margin-bottom:17px}.two{grid-template-columns:repeat(2,minmax(0,1fr))}.three{grid-template-columns:repeat(3,minmax(0,1fr))}.panel,.stat,.auth{min-width:0;padding:21px;border-radius:17px;border:1px solid var(--line);background:linear-gradient(145deg,#122239,#0d1a2b);box-shadow:0 14px 34px #0002}.stat{position:relative;overflow:hidden}.stat:after{content:"";position:absolute;right:-23px;top:-26px;width:90px;height:90px;border-radius:50%;background:var(--glow,var(--blue));opacity:.11}.stat-top{display:flex;justify-content:space-between;align-items:center;color:var(--muted);font-size:13px}.ico{width:36px;height:36px;display:grid;place-items:center;border-radius:11px;background:#203a59;color:var(--cyan);font-size:18px}.value{font-size:35px;font-weight:900;letter-spacing:-1px;margin-top:12px}.stat-foot{font-size:12px;color:var(--muted)}.bar{display:grid;grid-template-columns:105px 1fr 25px;align-items:center;gap:9px;margin:13px 0;font-size:12px}.track{height:8px;border-radius:99px;background:#23364d;overflow:hidden}.fill{height:100%;border-radius:99px;background:linear-gradient(90deg,var(--blue),var(--cyan))}.green{background:linear-gradient(90deg,#0ea876,#48e2ae)}.purple{background:linear-gradient(90deg,#8b5cf6,#c084fc)}.amber{background:linear-gradient(90deg,#e9a326,#ffda72)}.filters{display:grid;grid-template-columns:2fr repeat(3,minmax(115px,1fr)) auto auto;gap:10px;align-items:end}.field{display:flex;flex-direction:column;gap:7px;margin-bottom:14px}.field label{font-size:13px;color:#c6d4e6;font-weight:700}.field input,.field select,.field textarea,.filters input,.filters select{width:100%;min-width:0;background:#091626;border:1px solid #304760;border-radius:10px;padding:12px;color:var(--text);outline:none}.field input:focus,.field select:focus,.field textarea:focus,.filters input:focus,.filters select:focus{border-color:var(--blue);box-shadow:0 0 0 3px #4e8cff22}.field textarea{min-height:125px;resize:vertical}.table-wrap{overflow-x:auto;border:1px solid var(--line);border-radius:12px}table{width:100%;border-collapse:collapse;min-width:850px}th,td{text-align:left;padding:13px;border-bottom:1px solid var(--line);vertical-align:middle;font-size:12px}th{background:#14263b;color:#aebfd4;text-transform:uppercase;letter-spacing:.7px;font-size:10px;white-space:nowrap}tbody tr:hover{background:#172b41}tbody tr:last-child td{border:0}.badge{display:inline-flex;padding:5px 9px;border-radius:99px;font-size:10px;font-weight:850;white-space:nowrap}.pending{background:#49391b;color:#ffdb83}.in-progress{background:#173b65;color:#8cc4ff}.resolved{background:#123d35;color:#6ee7b7}.high{background:#492333;color:#ff9bad}.medium{background:#45351b;color:#ffd479}.low{background:#163a32;color:#72e5b9}.duplicate{background:#402b48;color:#e5b6ff}.flash{padding:12px 15px;border:1px solid #355b79;background:#132c43;border-radius:11px;margin:12px 0}.flash.error{border-color:#7e3548;background:#351b29}.empty{text-align:center;padding:36px;color:var(--muted)}.formgrid{display:grid;grid-template-columns:1fr 1fr;gap:0 15px}.span2{grid-column:1/-1}.authshell{min-height:calc(100vh - 80px);display:grid;place-items:center;padding:30px 14px}.auth{width:min(100%,470px);padding:29px}.auth h1{font-size:30px}.switch{text-align:center;border-top:1px solid var(--line);margin-top:18px;padding-top:16px;color:var(--muted)}.switch a{color:var(--cyan);font-weight:800}.code{font-family:ui-monospace,monospace;color:var(--cyan);font-size:12px;overflow-wrap:anywhere}.timeline{border-left:2px solid #2d4765;margin:20px 0 0 8px;padding-left:20px}.event{position:relative;margin-bottom:22px}.event:before{content:"";position:absolute;left:-27px;top:5px;width:10px;height:10px;border-radius:50%;background:var(--cyan);box-shadow:0 0 0 4px #123747}.event time,.notice time{display:block;font-size:12px;color:var(--muted);margin-top:4px}.notice{display:block;padding:14px;background:#13243a;border:1px solid var(--line);border-radius:12px;margin-bottom:10px}.photo{max-width:100%;max-height:380px;object-fit:contain;border-radius:12px;border:1px solid var(--line)}.footer{text-align:center;padding:25px;color:#7287a1;font-size:12px}@media(max-width:1000px){.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.three{grid-template-columns:1fr}.filters{grid-template-columns:repeat(2,minmax(0,1fr))}.hero{align-items:flex-start;flex-direction:column}}@media(max-width:620px){.top{position:static;align-items:flex-start;flex-direction:column;padding:12px}.nav{gap:1px}.nav a{font-size:12px;padding:7px}.who{display:none}.wrap{padding:16px 12px}.stats,.two,.formgrid{grid-template-columns:1fr}.span2{grid-column:auto}.filters{grid-template-columns:1fr}.panel{padding:15px}.value{font-size:29px}.auth{padding:22px}}
'''

def now(): return datetime.now(timezone.utc)
def txt(v): return str(escape(v if v is not None else ''))
def date_text(v):
    if not v: return '—'
    if isinstance(v, str): return v
    try: return v.astimezone().strftime('%d %b %Y, %I:%M %p')
    except Exception: return str(v)
def badge(v):
    label = str(v or 'Unknown'); cls = label.lower().replace(' ','-')
    if cls not in {'pending','in-progress','resolved','high','medium','low','duplicate'}: cls='pending'
    return f'<span class="badge {cls}">{txt(label)}</span>'
def page(title, body, active=''):
    name=session.get('name',''); role=session.get('role','')
    links=['<a href="/">Home</a>']
    if name:
        if role=='admin': links += [f'<a class="{"active" if active=="admin" else ""}" href="/admin">Dashboard</a>','<a href="/notifications">Notifications</a>']
        else: links += [f'<a class="{"active" if active=="report" else ""}" href="/report">Report issue</a>',f'<a class="{"active" if active=="tracking" else ""}" href="/my-complaints">My complaints</a>','<a href="/notifications">Notifications</a>']
        links += ['<a href="/logout">Log out</a>']
    else: links += ['<a href="/login">Log in</a>','<a href="/register">Create account</a>']
    messages=''.join(f'<div class="flash {"error" if cat=="error" else ""}">{txt(msg)}</div>' for cat,msg in __import__('flask').get_flashed_messages(with_categories=True))
    return render_template_string('''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{{title}} · CivicPulse</title><style>{{css|safe}}</style></head><body><header class="top"><a class="brand" href="/"><span class="logo">C</span><span>CivicPulse<small style="display:block;font-size:9px;color:#91a8c4;letter-spacing:1.5px">COMMUNITY ACTION</small></span></a><nav class="nav">{{links|safe}}</nav>{% if name %}<span class="who">● {{name}}</span>{% endif %}</header><main class="wrap">{{messages|safe}}{{body|safe}}</main><footer class="footer">CivicPulse · Small reports. Real community impact.</footer></body></html>''',title=title,css=CSS,links=''.join(links),name=name,messages=messages,body=body)
def login_required(fn):
    @wraps(fn)
    def inner(*a,**kw):
        if not session.get('user_id'): flash('Please log in to continue.'); return redirect(url_for('login'))
        return fn(*a,**kw)
    return inner
def admin_required(fn):
    @wraps(fn)
    def inner(*a,**kw):
        if not session.get('user_id') or session.get('role')!='admin': flash('Please log in with an administrator account.','error'); return redirect(url_for('login'))
        return fn(*a,**kw)
    return inner
def priority_for(category, desc):
    t=(category+' '+desc).lower()
    if any(x in t for x in ['fire','accident','electric shock','exposed wire','dangerous','emergency','sewage overflow','water leakage','water leak']): return 'High'
    if any(x in t for x in ['garbage','waste','pothole','streetlight','drainage','road damage','leak','broken']): return 'Medium'
    return 'Low'
def duplicate_for(category, location):
    return complaints.find_one({'category':{'$regex':'^'+re.escape(category.strip())+'$','$options':'i'},'location':{'$regex':'^'+re.escape(location.strip())+'$','$options':'i'},'status':{'$ne':'Resolved'}},sort=[('created_at',-1)]) if category and location else None
def get_doc(cid):
    try: d=complaints.find_one({'_id':ObjectId(cid)})
    except (InvalidId,TypeError): d=None
    if not d: abort(404)
    if session.get('role')!='admin' and str(d.get('user_id',''))!=str(session.get('user_id','')): abort(403)
    return d

@app.errorhandler(413)
def too_large(_):
    flash('Photo is too large. Choose an image under 5 MB.','error'); return redirect(request.referrer or url_for('report'))
@app.errorhandler(403)
def forbidden(_): return page('Access denied','<section class="panel"><h1>Access denied</h1><p class="muted">You cannot view this complaint.</p><a class="btn" href="/">Return home</a></section>'),403
@app.errorhandler(404)
def not_found(_): return page('Not found','<section class="panel"><h1>Page not found</h1><p class="muted">This page may have moved or is unavailable.</p><a class="btn" href="/">Return home</a></section>'),404

@app.route('/')
def home():
    total=complaints.count_documents({}); resolved=complaints.count_documents({'status':'Resolved'}); pending=complaints.count_documents({'status':'Pending'})
    body=f'''<section class="hero"><div><div class="eyebrow">Your neighbourhood. Your voice.</div><h1>Make your community<br><span style="color:var(--cyan)">better, together.</span></h1><p class="muted" style="max-width:590px">Report local issues, follow progress, and help turn everyday problems into visible action.</p><div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:20px"><a class="btn teal" href="{url_for('report') if session.get('user_id') and session.get('role')!='admin' else url_for('login')}">＋ Report an issue</a><a class="btn secondary" href="{url_for('my_complaints') if session.get('user_id') and session.get('role')!='admin' else url_for('login')}">Track a complaint →</a></div></div><section class="panel" style="min-width:230px"><div class="eyebrow">Community snapshot</div><div class="value">{total}</div><div class="muted">reports submitted</div><div style="display:flex;gap:24px;margin-top:15px"><div><b style="color:var(--green)">{resolved}</b><div class="muted">Resolved</div></div><div><b style="color:var(--amber)">{pending}</b><div class="muted">Pending</div></div></div></section></section><section class="grid three"><div class="panel"><div class="ico">✦</div><h3 style="margin-top:13px">Report simply</h3><p class="muted">Describe an issue, add a location and optional photo, then submit your report.</p></div><div class="panel"><div class="ico">↗</div><h3 style="margin-top:13px">Track progress</h3><p class="muted">See status, priority and the timeline of updates.</p></div><div class="panel"><div class="ico">◎</div><h3 style="margin-top:13px">Create impact</h3><p class="muted">Clear reports help administrators identify patterns and coordinate responses.</p></div></section>'''
    return page('Community action',body)

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        name=request.form.get('name','').strip(); email=request.form.get('email','').strip().lower(); password=request.form.get('password','')
        if not name or not email or len(password)<8: flash('Enter your name and email, and use a password of at least 8 characters.','error')
        else:
            try: users.insert_one({'name':name,'email':email,'password':generate_password_hash(password),'role':'citizen','created_at':now()}); flash('Account created. Please log in.'); return redirect(url_for('login'))
            except DuplicateKeyError: flash('An account with that email already exists.','error')
    body='''<div class="authshell"><section class="auth"><div class="logo" style="width:50px;height:50px;margin-bottom:18px">C</div><div class="eyebrow">Join your community</div><h1>Create account</h1><p class="muted">Make reports and follow every update.</p><form method="post"><div class="field"><label>Full name</label><input name="name" required maxlength="100" autocomplete="name" placeholder="Your name"></div><div class="field"><label>Email address</label><input name="email" type="email" required autocomplete="email" placeholder="you@example.com"></div><div class="field"><label>Password</label><input name="password" type="password" required minlength="8" autocomplete="new-password" placeholder="At least 8 characters"></div><button style="width:100%">Create account →</button></form><div class="switch">Already registered? <a href="/login">Log in</a></div></section></div>'''
    return page('Create account',body)
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        email=request.form.get('email','').strip().lower(); password=request.form.get('password',''); user=users.find_one({'email':email})
        if user and check_password_hash(user.get('password',''),password):
            session.clear(); session.update(user_id=str(user['_id']),role=user.get('role','citizen'),name=user.get('name','User'),email=user.get('email','')); flash('Welcome back, '+user.get('name','User')+'.'); return redirect(url_for('admin') if session['role']=='admin' else url_for('my_complaints'))
        flash('Email or password is incorrect.','error')
    body='''<div class="authshell"><section class="auth"><div class="logo" style="width:50px;height:50px;margin-bottom:18px">C</div><div class="eyebrow">Welcome back</div><h1>Log in to CivicPulse</h1><p class="muted">Your community updates are waiting.</p><form method="post"><div class="field"><label>Email address</label><input name="email" type="email" required autocomplete="username" placeholder="you@example.com"></div><div class="field"><label>Password</label><input name="password" type="password" required autocomplete="current-password" placeholder="Your password"></div><button style="width:100%">Log in →</button></form><div class="switch">New to CivicPulse? <a href="/register">Create an account</a></div></section></div>'''
    return page('Log in',body)
@app.route('/logout')
def logout(): session.clear(); flash('You have been logged out.'); return redirect(url_for('home'))
@app.route('/setup-admin',methods=['GET','POST'])
def setup_admin():
    if users.find_one({'role':'admin'}): abort(404)
    token=os.getenv('ADMIN_SETUP_TOKEN','')
    if not token: abort(404)
    if request.method=='POST':
        if not secrets.compare_digest(request.form.get('token',''),token): flash('Setup token is incorrect.','error')
        else:
            name=request.form.get('name','').strip(); email=request.form.get('email','').strip().lower(); password=request.form.get('password','')
            if not name or not email or len(password)<12: flash('Enter details and use a password of at least 12 characters.','error')
            else:
                try: users.insert_one({'name':name,'email':email,'password':generate_password_hash(password),'role':'admin','created_at':now()}); flash('Administrator created. Log in now.'); return redirect(url_for('login'))
                except DuplicateKeyError: flash('That email already exists.','error')
    body='<section class="auth" style="margin:30px auto"><h1>Initial admin setup</h1><form method="post"><div class="field"><label>Setup token</label><input name="token" type="password" required></div><div class="field"><label>Name</label><input name="name" required></div><div class="field"><label>Email</label><input name="email" type="email" required></div><div class="field"><label>Password (12+ characters)</label><input name="password" type="password" minlength="12" required></div><button>Create admin</button></form></section>'
    return page('Initial admin setup',body)

@app.route('/report')
@login_required
def report():
    if session.get('role')=='admin': return redirect(url_for('admin'))
    opts=''.join(f'<option>{txt(c)}</option>' for c in CATEGORIES)
    body=f'''<section class="hero"><div><div class="eyebrow">Citizen workspace</div><h1>Report an issue</h1><p class="muted">Share details so your local team can understand and respond.</p></div><a class="btn secondary" href="/my-complaints">My reports →</a></section><section class="panel" style="max-width:850px"><form action="/submit" method="post" enctype="multipart/form-data"><div class="formgrid"><div class="field"><label>Issue category</label><select name="category" required><option value="">Choose category</option>{opts}</select></div><div class="field"><label>Location</label><input name="location" required maxlength="180" placeholder="Street, area or landmark"></div><div class="field span2"><label>What happened?</label><textarea name="description" required maxlength="3000" placeholder="Describe the issue and any useful details."></textarea></div><div class="field span2"><label>Photo (optional, max 5 MB)</label><input type="file" name="photo" accept="image/png,image/jpeg,image/webp"><span class="hint">Accepted formats: JPG, PNG and WEBP.</span></div></div><button>Submit complaint →</button></form></section>'''
    return page('Report an issue',body,'report')
@app.route('/submit',methods=['POST'])
@login_required
def submit():
    if session.get('role')=='admin': return redirect(url_for('admin'))
    category=request.form.get('category','').strip(); location=request.form.get('location','').strip(); description=request.form.get('description','').strip()
    if category not in CATEGORIES or not location or not description: flash('Complete category, location and description.','error'); return redirect(url_for('report'))
    photo_name=None; file=request.files.get('photo')
    if file and file.filename:
        original=secure_filename(file.filename)
        if not original or '.' not in original or original.rsplit('.',1)[1].lower() not in ALLOWED: flash('Upload a JPG, PNG or WEBP image.','error'); return redirect(url_for('report'))
        photo_name=secrets.token_hex(12)+'.'+original.rsplit('.',1)[1].lower(); file.save(UPLOAD_FOLDER/photo_name)
    duplicate=duplicate_for(category,location); created=now()
    doc={'name':session.get('name','Citizen'),'category':category,'location':location,'description':description,'status':'Pending','priority':priority_for(category,description),'possible_duplicate':bool(duplicate),'user_id':session['user_id'],'user_email':session.get('email',''),'photo_name':photo_name,'created_at':created,'status_history':[{'status':'Pending','at':created,'note':'Complaint submitted'}],'notifications':[{'message':'Your complaint was submitted and is Pending.','at':created,'read':False}]}
    result=complaints.insert_one(doc); flash('Complaint submitted. Reference: '+str(result.inserted_id)[-8:].upper()); return redirect(url_for('complaint_detail',complaint_id=str(result.inserted_id)))

@app.route('/my-complaints')
@login_required
def my_complaints():
    if session.get('role')=='admin': return redirect(url_for('admin'))
    query={'user_id':session['user_id']}; status=request.args.get('status',''); priority=request.args.get('priority',''); category=request.args.get('category',''); term=request.args.get('q','').strip()
    if status in STATUSES: query['status']=status
    if priority in PRIORITIES: query['priority']=priority
    if category in CATEGORIES: query['category']=category
    if term:
        p=re.escape(term); query['$or']=[{k:{'$regex':p,'$options':'i'}} for k in ['category','location','description']]
    docs=list(complaints.find(query).sort('created_at',-1).limit(200))
    rows=''.join(f'<tr><td><a class="code" href="/complaint/{d["_id"]}">#{str(d["_id"])[-8:].upper()}</a><div class="muted">{txt(date_text(d.get("created_at")))}</div></td><td><b>{txt(d.get("category"))}</b><div class="muted">{txt(d.get("location"))}</div></td><td>{badge(d.get("priority"))}</td><td>{badge(d.get("status"))}</td><td><a class="btn secondary small" href="/complaint/{d["_id"]}">Details</a></td></tr>' for d in docs)
    def opts(items,sel): return ''.join(f'<option value="{txt(x)}" {"selected" if x==sel else ""}>{txt(x)}</option>' for x in items)
    body=f'''<section class="hero"><div><div class="eyebrow">Citizen workspace</div><h1>My complaints</h1><p class="muted">Follow reports and see status updates in one place.</p></div><a class="btn teal" href="/report">＋ New report</a></section><section class="panel"><form class="filters" method="get"><div class="field"><label>Search reports</label><input name="q" value="{txt(term)}" placeholder="Category, location, description"></div><div class="field"><label>Status</label><select name="status"><option value="">All statuses</option>{opts(STATUSES,status)}</select></div><div class="field"><label>Priority</label><select name="priority"><option value="">All priorities</option>{opts(PRIORITIES,priority)}</select></div><div class="field"><label>Category</label><select name="category"><option value="">All categories</option>{opts(CATEGORIES,category)}</select></div><button>Filter</button><a class="btn secondary" href="/my-complaints">Clear</a></form><p class="muted">{len(docs)} report(s) found</p><div class="table-wrap"><table><thead><tr><th>Reference / Date</th><th>Issue</th><th>Priority</th><th>Status</th><th></th></tr></thead><tbody>{rows or '<tr><td colspan="5"><div class="empty">No complaints found. Try changing filters or submit a report.</div></td></tr>'}</tbody></table></div></section>'''
    return page('My complaints',body,'tracking')

@app.route('/complaint/<complaint_id>')
@login_required
def complaint_detail(complaint_id):
    d=get_doc(complaint_id); cid=str(d['_id']); photo=''
    if d.get('photo_name'): photo=f'<section class="panel"><h2>Attached photo</h2><img class="photo" src="{url_for("static",filename="uploads/"+secure_filename(d["photo_name"]))}" alt="Complaint photo"></section>'
    timeline=''.join(f'<div class="event"><b>{txt(e.get("status","Update"))}</b><p class="muted">{txt(e.get("note","Status updated"))}</p><time>{txt(date_text(e.get("at")))}</time></div>' for e in reversed(d.get('status_history',[])))
    update=''
    if session.get('role')=='admin':
        opts=''.join(f'<option {"selected" if d.get("status")==s else ""}>{s}</option>' for s in STATUSES)
        update=f'<section class="panel"><h2>Update status</h2><form method="post" action="/admin/update/{cid}"><div class="field"><label>Status</label><select name="status">{opts}</select></div><div class="field"><label>Update note (optional)</label><input name="note" maxlength="300"></div><button>Save update</button></form></section>'
    back='/admin' if session.get('role')=='admin' else '/my-complaints'
    body=f'''<section class="hero"><div><div class="eyebrow">Complaint details</div><h1>Report <span class="code">#{cid[-8:].upper()}</span></h1><p class="muted">Submitted {txt(date_text(d.get('created_at')))}</p></div><a class="btn secondary" href="{back}">← Back</a></section><section class="grid two"><div class="panel"><div style="display:flex;justify-content:space-between;gap:10px"><h2>Issue summary</h2>{badge(d.get('status'))}</div><div class="eyebrow">Category</div><h3>{txt(d.get('category'))}</h3><div class="eyebrow" style="margin-top:18px">Location</div><p>{txt(d.get('location'))}</p><div class="eyebrow" style="margin-top:18px">Description</div><p style="white-space:pre-wrap">{txt(d.get('description'))}</p><p>Priority: {badge(d.get('priority'))} {' '+badge('Possible duplicate') if d.get('possible_duplicate') else ''}</p><p class="muted">Submitted by {txt(d.get('name','Citizen'))}</p></div><div class="panel"><h2>Status timeline</h2><div class="timeline">{timeline or '<p class="muted">No updates yet.</p>'}</div></div></section><div style="margin-top:16px">{photo}{update}</div>'''
    return page('Complaint details',body)

@app.route('/notifications')
@login_required
def notifications():
    q={'notifications.0':{'$exists':True}}
    if session.get('role')!='admin': q['user_id']=session['user_id']
    docs=list(complaints.find(q).sort('created_at',-1).limit(100)); items=[]
    for d in docs:
        for n in d.get('notifications',[]): items.append((n.get('at'),str(d['_id']),n.get('message','Complaint update')))
    items.sort(key=lambda x:x[0] or datetime.min.replace(tzinfo=timezone.utc),reverse=True)
    cards=''.join(f'<a class="notice" href="/complaint/{cid}"><b>{txt(msg)}</b><div class="muted">Complaint #{cid[-8:].upper()}</div><time>{txt(date_text(at))}</time></a>' for at,cid,msg in items[:100])
    return page('Notifications',f'<section class="hero"><div><div class="eyebrow">Updates</div><h1>Notifications</h1><p class="muted">Recent submission and status updates.</p></div></section><section class="panel">{cards or "<div class=empty>No notifications yet.</div>"}</section>')

@app.route('/admin')
@admin_required
def admin():
    total=complaints.count_documents({}); sc={s:complaints.count_documents({'status':s}) for s in STATUSES}; pc={p:complaints.count_documents({'priority':p}) for p in PRIORITIES}
    cats=list(complaints.aggregate([{'$group':{'_id':'$category','count':{'$sum':1}}},{'$sort':{'count':-1}},{'$limit':6}]))
    q={}; term=request.args.get('q','').strip(); status=request.args.get('status',''); priority=request.args.get('priority',''); category=request.args.get('category','')
    if status in STATUSES:q['status']=status
    if priority in PRIORITIES:q['priority']=priority
    if category in CATEGORIES:q['category']=category
    if term:
        p=re.escape(term); q['$or']=[{k:{'$regex':p,'$options':'i'}} for k in ['name','user_email','category','location','description']]
    docs=list(complaints.find(q).sort('created_at',-1).limit(300))
    def bars(data,colors={}):
        return ''.join(f'<div class="bar"><span>{txt(label)}</span><div class="track"><div class="fill {colors.get(label,"")}" style="width:{count/max(total,1)*100:.1f}%"></div></div><b>{count}</b></div>' for label,count in data)
    statusbars=bars([(s,sc[s]) for s in STATUSES],{'Resolved':'green','In Progress':'purple'}); prioritybars=bars([(p,pc[p]) for p in PRIORITIES],{'Medium':'amber','Low':'green'}); catbars=bars([(c['_id'] or 'Other',c['count']) for c in cats])
    def opts(items,sel):return ''.join(f'<option value="{txt(x)}" {"selected" if x==sel else ""}>{txt(x)}</option>' for x in items)
    rows=''
    for d in docs:
        cid=str(d['_id']); st=''.join(f'<option {"selected" if d.get("status")==s else ""}>{s}</option>' for s in STATUSES)
        photo=f'<a href="{url_for("static",filename="uploads/"+secure_filename(d["photo_name"]))}" target="_blank" rel="noopener">View</a>' if d.get('photo_name') else '—'
        dup=badge('Duplicate') if d.get('possible_duplicate') else '<span class="muted">No</span>'
        rows+=f'<tr><td><a class="code" href="/complaint/{cid}">#{cid[-8:].upper()}</a><div>{txt(d.get("name"))}</div><div class="muted">{txt(d.get("user_email"))}</div></td><td>{txt(d.get("category"))}</td><td>{txt(d.get("location"))}</td><td style="min-width:180px;max-width:250px">{txt(d.get("description"))}</td><td>{photo}</td><td>{badge(d.get("priority"))}</td><td>{badge(d.get("status"))}</td><td>{dup}</td><td><form method="post" action="/admin/update/{cid}" style="display:flex;gap:5px;min-width:160px"><select name="status" aria-label="Status">{st}</select><button class="small">Save</button></form></td></tr>'
    body=f'''<section class="hero"><div><div class="eyebrow">Operations centre / Administrator</div><h1>Welcome, {txt(session.get('name','Admin'))}.</h1><p class="muted">Monitor issues, spot patterns, and keep reports moving.</p></div><a class="btn teal" href="/notifications">View updates ↗</a></section><section class="grid stats"><div class="stat"><div class="stat-top">Total complaints <span class="ico">▤</span></div><div class="value">{total}</div><div class="stat-foot">All submitted reports</div></div><div class="stat" style="--glow:#ffc857"><div class="stat-top">Pending <span class="ico">◷</span></div><div class="value">{sc['Pending']}</div><div class="stat-foot">Awaiting action</div></div><div class="stat"><div class="stat-top">In progress <span class="ico">↗</span></div><div class="value">{sc['In Progress']}</div><div class="stat-foot">Being handled</div></div><div class="stat" style="--glow:#35d39a"><div class="stat-top">Resolved <span class="ico">✓</span></div><div class="value">{sc['Resolved']}</div><div class="stat-foot">{sc['Resolved']/max(total,1)*100:.0f}% of reports</div></div></section><section class="grid three" style="margin-bottom:17px"><div class="panel"><h2>Complaints by status</h2>{statusbars}</div><div class="panel"><h2>Priority distribution</h2>{prioritybars}</div><div class="panel"><h2>Top categories</h2>{catbars or '<p class="muted">No category data yet.</p>'}</div></section><section class="panel"><div class="hero" style="margin:0 0 15px"><div><h2>Complaint management</h2><p class="muted">Search, review attachments, and update status.</p></div><span class="who">{len(docs)} shown · max 300</span></div><form class="filters" method="get"><div class="field"><label>Search</label><input name="q" value="{txt(term)}" placeholder="Citizen, email, category, location"></div><div class="field"><label>Status</label><select name="status"><option value="">All statuses</option>{opts(STATUSES,status)}</select></div><div class="field"><label>Priority</label><select name="priority"><option value="">All priorities</option>{opts(PRIORITIES,priority)}</select></div><div class="field"><label>Category</label><select name="category"><option value="">All categories</option>{opts(CATEGORIES,category)}</select></div><button>Apply filters</button><a class="btn secondary" href="/admin">Clear</a></form><p class="muted" style="font-size:12px">Changing a status records the update in the complaint timeline.</p><div class="table-wrap"><table><thead><tr><th>Citizen / Reference</th><th>Category</th><th>Location</th><th>Description</th><th>Photo</th><th>Priority</th><th>Status</th><th>Duplicate</th><th>Update status</th></tr></thead><tbody>{rows or '<tr><td colspan="9"><div class="empty">No matching complaints. Try changing filters.</div></td></tr>'}</tbody></table></div></section>'''
    return page('Admin dashboard',body,'admin')

@app.route('/admin/update/<complaint_id>',methods=['POST'])
@admin_required
def update_status(complaint_id):
    try: oid=ObjectId(complaint_id)
    except (InvalidId,TypeError): abort(404)
    d=complaints.find_one({'_id':oid})
    if not d: abort(404)
    status=request.form.get('status',''); note=request.form.get('note','').strip()
    if status not in STATUSES: flash('Invalid status selected.','error'); return redirect(request.referrer or url_for('admin'))
    if d.get('status')!=status:
        at=now(); message=f'Your complaint #{str(oid)[-8:].upper()} status changed to {status}.'
        complaints.update_one({'_id':oid},{'$set':{'status':status,'updated_at':at},'$push':{'status_history':{'status':status,'at':at,'note':note or f'Status changed to {status}'},'notifications':{'message':message,'at':at,'read':False}}})
        flash('Complaint status updated; notification and timeline recorded.')
    else: flash('The complaint already has that status.')
    return redirect(request.referrer or url_for('admin'))

if __name__=='__main__': app.run(debug=True,port=5001)